const captions = [
  "Paws-itively adorable!",
  "Who’s a good influencer? 🐶",
  "Wag more, bark less.",
  "Living my best pup life 🐾",
  "Frenchie vibes only.",
  "Too glam to give a damn 🐕",
  "Caption game strong!"
];

function generateCaption() {
  const randomIndex = Math.floor(Math.random() * captions.length);
  document.getElementById("caption").innerText = captions[randomIndex];
}
